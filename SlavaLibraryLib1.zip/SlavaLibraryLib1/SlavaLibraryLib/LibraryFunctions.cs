﻿using System;
using System.Collections.Generic;

namespace SlavaLibraryLib
{
    // Класс-библиотека: хранит данные и умеет с ними работать
    public class LibraryFunctions
    {
        // Название библиотеки (не меняется)
        private string LibraryName = "Городская библиотека г. Чита";

        // Текущий главный библиотекарь
        private string _chiefLibrarian = "Иванова Мария Петровна";

        // Список сотрудников библиотеки
        // readonly — саму ссылку на список нельзя заменить,
        // но добавлять/удалять элементы можно
        private readonly List<string> _staff = new List<string>
        {
            "Петров П.С.",
            "Сидорова А.В.",
            "Козлов И.Д.",
            "Иванов М.П."
        };

        // Генератор случайных чисел
        private readonly Random _random = new Random();

        // Вернуть имя главного библиотекаря
        public string GetChiefLibrarian()
        {
            return _chiefLibrarian;
        }

        // Вернуть название библиотеки
        public string GetLibraryName()
        {
            return LibraryName;
        }

        // Сменить главного библиотекаря.
        // true  — если сотрудник есть в списке и назначен;
        // false — если имя пустое или такого сотрудника нет
        public bool SetChiefLibrarian(string fullname)
        {
            // Пустое имя (null, "", "   ") — не принимаем
            if (string.IsNullOrWhiteSpace(fullname))
            {
                return false;
            }

            // Сотрудник есть в списке — назначаем
            if (_staff.Contains(fullname))
            {
                _chiefLibrarian = fullname;
                return true;
            }

            // Такого сотрудника нет - отказ
            return false;
        }

        // Сгенерировать код книги вида "CAT_номер"
        public string GenerateBookCode(string category, int number)
        {
            int codeNumber;

            // Если число положительное — используем его
            if (number > 0)
            {
                codeNumber = number;
            }
            // Иначе — берём случайное от 1 до 9999
            else
            {
                codeNumber = _random.Next(1, 10000);
            }

            // Склеиваем категорию и номер через "_"
            return category + "_" + codeNumber;
        }

        // Вернуть КОПИЮ списка сотрудников,
        // чтобы снаружи нельзя было изменить внутренний список
        public List<string> GetStaff()
        {
            return new List<string>(_staff);
        }

        // Добавить сотрудника в список
        public void AddStaff(string fullname)
        {
            // Пустое имя — ничего не делаем
            if (string.IsNullOrWhiteSpace(fullname))
            {
                return;
            }

            // Имя нормальное — добавляем
            _staff.Add(fullname);
        }
    }
}